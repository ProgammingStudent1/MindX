function closeForm() {
  document.getElementById("myForm").style.display = "none";
  document.getElementById("open-chat").style.display = "block";
}

function openForm() {
  document.getElementById("myForm").style.display = "block";
  document.getElementById("open-chat").style.display = "none";
}
