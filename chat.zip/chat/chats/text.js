let filter = "";
var messages = [];

db.collection("message").onSnapshot(function (querySnapshot) {
  messages = [];
  querySnapshot.forEach(function (doc) {
    messages.push({
      userId: doc.data().userId,
      name: doc.data().name,
      avatar: doc.data().avatar,
      text: doc.data().text,
      status: doc.data().status,
    });
  });
  console.log(messages);
  renderMessages();
});

function renderMessages() {
  var messageElement = "";
  messages.forEach(function (message) {
    console.log(filter, message.userId);

    if (filter == message.userId || filter == "") {
      messageElement += render(message);
    }
  });
  console.log(messageElement);
  document.querySelector("#container").innerHTML = messageElement;
}

var onUserSelected = function (id) {
  filter = id;
  renderMessages();
};

function render(message) {
  if (message.name == "Phong") {
    return `<div class="container" style="background-color: goldenrod;">
  <img src="${message.avatar}">
    <p>${message.text}</p>
    <span class="time-right">${message.name}</span>
  </div>`;
  } else {
    return `<div class="container" style="background-color: lightblue;">
  <img src="${message.avatar}">
    <p>${message.text}</p>
    <span class="time-right">${message.name}</span>
  </div>`;
  }
}

function send() {
  let text = document.querySelector("#input").value;

  db.collection("message")
    .add({
      text: text,
      userId: "AKdArdZjNkB9bp3AVvkE",
      name: "Phong",
      avatar:
        "https://i.pinimg.com/originals/61/98/06/619806b527ce3101cace7975497c249e.jpg",
    })
    .then(function (docRef) {
      console.log("Document written with ID: ", docRef.id);
    })
    .catch(function (error) {
      console.error("Error adding document: ", error);
    });
}
